const express = require("express");
const mongoose = require("mongoose");

const app = express();
const PORT = 6789;

mongoose
  .connect("mongodb+srv://aluno:<db_password>@ws2024.qvolp.mongodb.net/?retryWrites=true&w=majority&appName=ws2024")
  .then(()=>console.log("Connected to mongodb"))
  .catch(err => console.error("Cannoct connect", err));

  app.listen(PORT, ()=>{
    console.log("Server is running");
  });
